import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InscripcionServiceTest {

    private InscripcionService service;

    @BeforeEach
    public void setUp(){
        FakeCorreoService.reset();
        FakeCorreoService fakeCorreo = new FakeCorreoService();
        service = new InscripcionService(fakeCorreo);
    }

    @Nested
    class CasosExitosos{
        @Test
        public void testInscripcionExitosaConTalle(){
            // Arrange => Preparamos el escenario con 5 cupos iniciales
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            FakeCorreoService fakeCorreo = new FakeCorreoService();

            // Act => Ejecutas los métodos a probar
            ResultadoInscripcion resultado = service.inscribir(visitante, tirolesa,
                    "14:00", 1, true);

            // Assert => Verificamos que salio bien
            assertTrue(resultado.isExitosa(), "La inscripción debería ser exitosa");
            assertTrue(fakeCorreo.seEnvioElMail(), "Debería enviar el mail de confirmación al cliente");
            assertEquals("Inscripción confirmada", resultado.getMensaje());
            assertEquals(4, tirolesa.getCuposDisponibles("14:00"), "Debería restar 1 cupo");
        }

        @Test
        public void testInscripcionExitosaSafariSinTalle() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, null);
            Actividad safari = new Actividad("Safari", false);
            safari.agregarHorario("10:00", 1);

            ResultadoInscripcion resultado = service.inscribir(visitante,
                    safari, "10:00", 1, true);

            assertTrue(resultado.isExitosa());
        }

    }

    @Nested
    class CasosFallidos {
        // Nombre
        @Test
        public void testFallaPorNombreVacio() {
            Visitante visitante = new Visitante("", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception excepcionAtrapada = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));

            assertEquals("El nombre del visitante no puede estar vacío", excepcionAtrapada.getMessage());

        }

        @Test
        public void testFallaPorNombreNulo() {
            Visitante visitante = new Visitante(null, "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El nombre del visitante no puede ser nulo", ex.getMessage());
        }

        @Test
        public void testFallaPorNombreExcesivamenteLargo(){
            String nombreLargo = "FabrizzioFranciscoIgnacioPerez" +
                    "EsElNombreMasLargoDeLaHistoriaTantoAsiQueTieneRecordGuiness";
            Visitante visitante = new Visitante(nombreLargo, "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El nombre excede la longitud máxima permitida", ex.getMessage());
        }

        @Test
        public void testFallaPorNombreConSoloEspacios(){
            Visitante visitante = new Visitante("     ", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);


            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El nombre del visitante no puede estar vacío ni contener solo espacios",
                    ex.getMessage());
        }


        // DNI
        @Test
        public void testFallaPorDniVacio() {
            Visitante visitante = new Visitante("Fabrizzio", "", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception excepcionAtrapada = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));

            assertEquals("El dni del visitante no puede estar vacío", excepcionAtrapada.getMessage());
        }

        @Test
        public void testFallaPorDniConSoloEspacios() {
            Visitante visitante = new Visitante("Fabrizzio", "        ", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El dni del visitante no puede estar vacío ni contener solo espacios",
                    ex.getMessage());
        }

        @Test
        public void testFallaPorDniAlfanumerico() {
            Visitante visitante = new Visitante("Fabrizzio", "45A12312", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El DNI debe contener solo números", ex.getMessage());
        }

        @Test
        public void testFallaPorDniDemasiadoCorto(){
            Visitante visitante = new Visitante ("Fabrizzio", "123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El DNI debe tener al menos 7 dígitos", ex.getMessage());
        }

        // Edad
        @Test
        public void testFallaPorEdadVacia() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception excepcionAtrapada = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));

            assertEquals("La edad del visitante no puede estar vacía", excepcionAtrapada.getMessage());
        }

        @Test
        public void testFallaPorEdadCero() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 0, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La edad debe ser mayor a 0", ex.getMessage());
        }

        @Test
        public void testFallaPorEdadNegativa() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", -5, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La edad no puede ser negativa", ex.getMessage());
        }

        @Test
        public void testFallaPorEdadIrracionalmenteAlta(){
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 150, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5); // Aseguramos cupo suficiente

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La edad ingresada no es válida para el parque", ex.getMessage());
        }

        // Talle
        @Test
        public void testFallaPorFaltaDeTalleCuandoEsRequerido() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "");
            Actividad tirolesa = new Actividad("Tirolesa", true); // TRUE = exige talle
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La actividad requiere especificar una talla de vestimenta", ex.getMessage());
        }

        @Test
        public void testFallaPorTalleInvalido() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "Z");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La talla de vestimenta ingresada no es válida", ex.getMessage());
        }


        // Cupos
        @Test
        public void testFallaPorCantidadCeroPersonas() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 0);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 0, true));
            assertEquals("La cantidad de personas a inscribir debe ser al menos 1", ex.getMessage());
        }

        @Test
        public void testFallaPorCantidadPersonasNegativa() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", -1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", -1, true));
            assertEquals("La cantidad de personas no puede ser negativa", ex.getMessage());
        }

        @Test
        public void testFallaPorExcederCupoDisponible() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);

            // Pedimos 100 cupos para forzar inequívocamente la falla de cupo antes de cualquier otra lógica
            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 100, true));
            assertEquals("No hay suficientes cupos disponibles para este horario", ex.getMessage());
        }

        // Terminos y Condiciones
        @Test
        public void testFallaPorTerminosNoAceptados() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            // Pasamos 'false' en el último parámetro (términos)
            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, false));
            assertEquals("Debe aceptar los términos y condiciones para inscribirse", ex.getMessage());
        }

        // Null visitante
        @Test
        public void testFallaPorVisitanteTotalmenteNulo() {
            // Simulamos que el Frontend no mandó los datos del visitante
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 1);

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(null, tirolesa, "14:00", 1,
                            true)); // Visitante null
            assertEquals("Los datos del visitante son obligatorios y no pueden ser nulos", ex.getMessage());
        }

        // Visitante ya inscrito para el mismo horario
        @Test
        public void testFallaPorVisitanteYaInscritoEnEsaActividadYHorario() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 10); // <=== CAMBIÁ EL 5 O EL 1 POR UN 10 ACÁ

            // Primera inscripción (Consume 1 cupo, quedan 9. Pasa exitoso)
            service.inscribir(visitante, tirolesa, "14:00", 1, true);

            // Segunda inscripción (Tiene cupo disponible, por ende cae en la regla de doble inscripción)
            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El visitante ya se encuentra " +
                    "inscrito en esta actividad para el horario seleccionado", ex.getMessage());
        }
    }
}

