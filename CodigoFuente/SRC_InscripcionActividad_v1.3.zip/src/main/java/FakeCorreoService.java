public class FakeCorreoService implements ICorreoService{
    private static boolean mailEnviado = false;

    @Override
    public void enviarMail() {
        mailEnviado = true;
    }

    public boolean seEnvioElMail() {
        return mailEnviado;
    }

    public static void reset() {
        mailEnviado = false;
    }
}
