public class Visitante {
    private final String nombre;
    private final String dni;
    private final Integer edad;
    private final String talle;

    public Visitante(String nombre, String dni, int edad, String talle) {
        this.nombre = nombre;
        this.dni = dni;
        this.edad = edad;
        this.talle = talle;
    }

    public Visitante(String nombre, String dni, String talle) {
        this.nombre = nombre;
        this.dni = dni;
        this.edad = null;
        this.talle = talle;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    public Integer getEdad() {
        return edad;
    }

    public String getTalle() {
        return talle;
    }
}
