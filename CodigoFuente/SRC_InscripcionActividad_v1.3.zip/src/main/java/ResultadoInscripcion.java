public class ResultadoInscripcion {
    private final boolean exitosa;
    private final String mensaje;

    public ResultadoInscripcion(boolean exitosa, String mensaje) {
        this.exitosa = exitosa;
        this.mensaje = mensaje;
    }

    public boolean isExitosa() {
        return exitosa;
    }

    public String getMensaje() {
        return mensaje;
    }
}
