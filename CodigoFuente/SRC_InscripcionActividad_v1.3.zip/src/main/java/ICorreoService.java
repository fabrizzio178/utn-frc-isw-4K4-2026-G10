public interface ICorreoService {
    void enviarMail();
}
