import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InscripcionServiceTest {

    @Nested
    class CasosExitosos{
        @Test
        public void testInscripcionExitosaConTalle(){
            // Arrange => Preparamos el escenario, instanciamos clases etc
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            FakeCorreoService fakeCorreo = new FakeCorreoService();
            InscripcionService service = new InscripcionService();

            // Act => Ejecutas los métodos a probar
            ResultadoInscripcion resultado = service.inscribir(visitante, tirolesa, "14:00", 1, true);

            // Assert => Verificamos que salio bien
            assertTrue(resultado.isExitosa(), "La inscripción debería ser exitosa");
            assertTrue(fakeCorreo.seEnvioElMail(), "Debería enviar el mail de confirmación al cliente");
            assertEquals("Inscripción confirmada", resultado.getMensaje());
            assertEquals(4, tirolesa.getCuposDisponibles("14:00"), "Debería restar 1 cupo");
        }

        @Test
        public void testInscripcionExitosaSafariSinTalle() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, null);
            Actividad safari = new Actividad("Safari", false);
            safari.agregarHorario("10:00", 10);
            InscripcionService service = new InscripcionService();

            ResultadoInscripcion resultado = service.inscribir(visitante, safari, "10:00", 1, true);

            assertTrue(resultado.isExitosa());
        }

        @Test
        public void testInscripcionExitosaAlLimiteDelCupo() {
            // Valor Límite: Quedan 5 cupos, pido exactamente 5.
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            ResultadoInscripcion resultado = service.inscribir(visitante, tirolesa, "14:00", 5, true);
            assertTrue(resultado.isExitosa());
            assertEquals(0, tirolesa.getCuposDisponibles("14:00")); // Se llenó
        }

    }

    @Nested
    class CasosFallidos {
        // Nombre
        @Test
        public void testFallaPorNombreVacio() {
            Visitante visitante = new Visitante("", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception excepcionAtrapada = assertThrows(RuntimeException.class, () -> {
                service.inscribir(visitante, tirolesa, "14:00", 1, true);
            });

            assertEquals("El nombre del visitante no puede estar vacío", excepcionAtrapada.getMessage());

        }

        @Test
        public void testFallaPorNombreNulo() {
            Visitante visitante = new Visitante(null, "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El nombre del visitante no puede ser nulo", ex.getMessage());
        }

        @Test
        public void testFallaPorNombreExcesivamenteLargo(){
            String nombreLargo = "FabrizzioFranciscoIgnacioEsElNombreMasLargoDeLaHistoriaTantoAsiQueTieneRecordGuiness";
            Visitante visitante = new Visitante(nombreLargo, "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El nombre excede la longitud máxima permitida", ex.getMessage());
        }

        @Test
        public void testFallaPorNombreConSoloEspacios(){
            Visitante visitante = new Visitante("     ", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El nombre del visitante no puede estar vacío ni contener solo espacios",
                    ex.getMessage());
        }


        // DNI
        @Test
        public void testFallaPorDniVacio() {
            Visitante visitante = new Visitante("Fabrizzio", "", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception excepcionAtrapada = assertThrows(RuntimeException.class, () -> {
                service.inscribir(visitante, tirolesa, "14:00", 1, true);
            });

            assertEquals("El dni del visitante no puede estar vacío", excepcionAtrapada.getMessage());
        }

        @Test
        public void testFallaPorDniConSoloEspacios() {
            Visitante visitante = new Visitante("Fabrizzio", "        ", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El dni del visitante no puede estar vacío ni contener solo espacios",
                    ex.getMessage());
        }

        @Test
        public void testFallaPorDniAlfanumerico() {
            Visitante visitante = new Visitante("Fabrizzio", "45A12312", 22, "L"); // DNI con letras
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El DNI debe contener solo números", ex.getMessage());
        }

        @Test
        public void testFallaPorDniDemasiadoCorto(){
            Visitante visitante = new Visitante ("Fabrizzio", "123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", true);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El DNI debe tener al menos 7 dígitos", ex.getMessage());
        }

        // Edad
        @Test
        public void testFallaPorEdadVacia() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception excepcionAtrapada = assertThrows(RuntimeException.class, () -> {
                service.inscribir(visitante, tirolesa, "14:00", 1, true);
            });

            assertEquals("La edad del visitante no puede estar vacía", excepcionAtrapada.getMessage());
        }

        @Test
        public void testFallaPorEdadCero() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 0, "L"); // Límite inferior
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La edad debe ser mayor a 0", ex.getMessage());
        }

        @Test
        public void testFallaPorEdadNegativa() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", -5, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La edad no puede ser negativa", ex.getMessage());
        }

        @Test
        public void testFallaPorEdadIrracionalmenteAlta(){
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 150, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 3);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La edad ingresada no es válida para el parque", ex.getMessage());
        }

        // Talle
        @Test
        public void testFallaPorFaltaDeTalleCuandoEsRequerido() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, ""); // Talle vacío
            Actividad tirolesa = new Actividad("Tirolesa", true); // TRUE = exige talle
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La actividad requiere especificar una talla de vestimenta", ex.getMessage());
        }

        @Test
        public void testFallaPorTalleInvalido() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "Z"); // Talle que no existe
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La talla de vestimenta ingresada no es válida", ex.getMessage());
        }

        @Test
        public void testFallaPorTalleConCaracteresEspeciales() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L@"); // Inyección de basura
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("La talla de vestimenta contiene caracteres inválidos", ex.getMessage());
        }

        // Cupos
        @Test
        public void testFallaPorCantidadCeroPersonas() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 0, true)); // 0 personas
            assertEquals("La cantidad de personas a inscribir debe ser al menos 1", ex.getMessage());
        }

        @Test
        public void testFallaPorCantidadPersonasNegativa() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", -1, true));
            assertEquals("La cantidad de personas no puede ser negativa", ex.getMessage());
        }

        @Test
        public void testFallaPorExcederCupoDisponible() {
            // Valor Límite: Quedan 5 cupos, pido 6.
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 6, true));
            assertEquals("No hay suficientes cupos disponibles para este horario", ex.getMessage());
        }

        // Actividad
        @Test
        public void testFallaPorActividadNula() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, null, "14:00", 1, true));
            assertEquals("Debe seleccionar una actividad válida", ex.getMessage());
        }

        @Test
        public void testFallaPorActividadInexistenteEnParque() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            // La US dice: Tirolesa, Safari, Palestra, Jardinería. Natación no existe.
            Actividad natacion = new Actividad("Natación", false);
            natacion.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, natacion, "14:00", 1, true));
            assertEquals("La actividad seleccionada no pertenece a EcoHarmony Park", ex.getMessage());
        }

        // Terminos y Condiciones
        @Test
        public void testFallaPorTerminosNoAceptados() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            // Pasamos 'false' en el último parámetro (términos)
            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, false));
            assertEquals("Debe aceptar los términos y condiciones para inscribirse", ex.getMessage());
        }

        // Horarios
        @Test
        public void testFallaPorHorarioVacio() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "", 1, true));
            assertEquals("El horario seleccionado no puede estar vacío", ex.getMessage());
        }

        @Test
        public void testFallaPorHorarioFueraDeFormato() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "25:99", 1, true)); // Hora absurda
            assertEquals("El formato del horario es inválido", ex.getMessage());
        }

        @Test
        public void testFallaPorHorarioNoHabilitadoEnLaActividad() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5); // Solo hay a las 14:00
            InscripcionService service = new InscripcionService();

            // Intenta anotarse a las 16:00
            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "16:00", 1, true));
            assertEquals("El horario seleccionado no está disponible para esta actividad", ex.getMessage());
        }

        @Test
        public void testFallaPorParqueCerrado() {
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("03:00", 5); // Madrugada
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "03:00", 1, true));
            assertEquals("No se pueden realizar inscripciones en horarios donde el parque está cerrado",
                    ex.getMessage());
        }

        // Null visitante
        @Test
        public void testFallaPorVisitanteTotalmenteNulo() {
            // Simulamos que el Frontend no mandó los datos del visitante
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(null, tirolesa, "14:00", 1, true)); // Visitante null
            assertEquals("Los datos del visitante son obligatorios y no pueden ser nulos", ex.getMessage());
        }

        // Visitante ya inscrito para el mismo horario
        @Test
        public void testFallaPorVisitanteYaInscritoEnEsaActividadYHorario() {
            // Simulamos a alguien intentando acaparar lugares anotándose dos veces
            Visitante visitante = new Visitante("Fabrizzio", "45123123", 22, "L");
            Actividad tirolesa = new Actividad("Tirolesa", true);
            tirolesa.agregarHorario("14:00", 5);
            InscripcionService service = new InscripcionService();

            // Primera inscripción (DEBE pasar)
            service.inscribir(visitante, tirolesa, "14:00", 1, true);

            // Segunda inscripción del mismo visitante, misma actividad, misma hora (DEBE fallar)
            Exception ex = assertThrows(RuntimeException.class, () ->
                    service.inscribir(visitante, tirolesa, "14:00", 1, true));
            assertEquals("El visitante ya se encuentra inscrito en esta " +
                    "actividad para el horario seleccionado", ex.getMessage());
        }


    }




}

