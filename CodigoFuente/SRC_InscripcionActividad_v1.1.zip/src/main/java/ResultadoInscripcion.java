public class ResultadoInscripcion {
    private boolean exitosa;
    private String mensaje;

    public ResultadoInscripcion(boolean exitosa, String mensaje) {
        this.exitosa = exitosa;
        this.mensaje = mensaje;
    }

    public boolean isExitosa() {
        return exitosa;
    }

    public String getMensaje() {
        return mensaje;
    }
}
