import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Actividad {
    private String nombre;
    private boolean requiereTalle;
    private Map<String, Integer> horarios;
    private Set<String> inscritos;

    public Actividad(String nombre, boolean requiereTalle) {
        this.nombre = nombre;
        this.requiereTalle = requiereTalle;
        this.horarios = new HashMap<>();
        this.inscritos = new HashSet<>();
    }

    public void agregarHorario(String horario, int cupos) {
        horarios.put(horario, cupos);
    }

    public void agregarHorario(String horario, boolean valor) {
        horarios.put(horario, 5);
    }

    public int getCuposDisponibles(String horario) {
        return horarios.getOrDefault(horario, 0);
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isRequiereTalle() {
        return requiereTalle;
    }

    public void restarCupos(String horario, int cantidad) {
        int actuales = horarios.getOrDefault(horario, 0);
        horarios.put(horario, actuales - cantidad);
    }

    public boolean isHorarioDisponible(String horario) {
        return horarios.containsKey(horario);
    }

    public void registrarInscrito(String dni, String horario) {
        inscritos.add(dni + "_" + horario);
    }

    public boolean isInscrito(String dni, String horario) {
        return inscritos.contains(dni + "_" + horario);
    }
}
