import java.util.Set;
import java.util.regex.Pattern;

public class InscripcionService {
    private static final Set<String> ACTIVIDADES_VALIDAS = Set.of("Tirolesa", "Safari", "Palestra", "Jardinería");
    private static final Set<String> TALLES_VALIDOS = Set.of("XS", "S", "M", "L", "XL", "XXL");
    private static final Pattern HORARIO_PATTERN = Pattern.compile("^([01]\\d|2[0-3]):[0-5]\\d$");
    private static final int HORA_APERTURA = 8;
    private static final int HORA_CIERRE = 20;
    private static final int MAX_LONGITUD_NOMBRE = 50;
    private static final int MIN_DIGITOS_DNI = 7;
    private static final int MAX_EDAD = 120;

    public ResultadoInscripcion inscribir(Visitante visitante, Actividad actividad, String horario, int cantidadPersonas, boolean aceptaTerminos) {
        validarVisitanteNoNulo(visitante);
        validarNombre(visitante.getNombre());
        validarDni(visitante.getDni());
        validarEdad(visitante.getEdad());
        validarActividadNoNula(actividad);
        validarActividadValida(actividad.getNombre());
        validarHorario(horario);
        validarHorarioDisponible(actividad, horario);
        validarParqueAbierto(horario);
        validarCantidadPersonas(cantidadPersonas);
        validarCuposDisponibles(actividad, horario, cantidadPersonas);
        validarTalle(actividad.isRequiereTalle(), visitante.getTalle());
        validarTerminos(aceptaTerminos);
        validarNoDobleInscripcion(visitante.getDni(), actividad, horario);

        actividad.restarCupos(horario, cantidadPersonas);
        actividad.registrarInscrito(visitante.getDni(), horario);
        FakeCorreoService.enviarMail();

        return new ResultadoInscripcion(true, "Inscripción confirmada");
    }

    private void validarVisitanteNoNulo(Visitante visitante) {
        if (visitante == null) {
            throw new RuntimeException("Los datos del visitante son obligatorios y no pueden ser nulos");
        }
    }

    private void validarNombre(String nombre) {
        if (nombre == null) {
            throw new RuntimeException("El nombre del visitante no puede ser nulo");
        }
        if (nombre.isEmpty()) {
            throw new RuntimeException("El nombre del visitante no puede estar vacío");
        }
        if (nombre.trim().isEmpty()) {
            throw new RuntimeException("El nombre del visitante no puede estar vacío ni contener solo espacios");
        }
        if (nombre.length() > MAX_LONGITUD_NOMBRE) {
            throw new RuntimeException("El nombre excede la longitud máxima permitida");
        }
    }

    private void validarDni(String dni) {
        if (dni == null || dni.isEmpty()) {
            throw new RuntimeException("El dni del visitante no puede estar vacío");
        }
        if (dni.trim().isEmpty()) {
            throw new RuntimeException("El dni del visitante no puede estar vacío ni contener solo espacios");
        }
        if (!dni.matches("\\d+")) {
            throw new RuntimeException("El DNI debe contener solo números");
        }
        if (dni.length() < MIN_DIGITOS_DNI) {
            throw new RuntimeException("El DNI debe tener al menos 7 dígitos");
        }
    }

    private void validarEdad(Integer edad) {
        if (edad == null) {
            throw new RuntimeException("La edad del visitante no puede estar vacía");
        }
        if (edad < 0) {
            throw new RuntimeException("La edad no puede ser negativa");
        }
        if (edad <= 0) {
            throw new RuntimeException("La edad debe ser mayor a 0");
        }
        if (edad > MAX_EDAD) {
            throw new RuntimeException("La edad ingresada no es válida para el parque");
        }
    }

    private void validarActividadNoNula(Actividad actividad) {
        if (actividad == null) {
            throw new RuntimeException("Debe seleccionar una actividad válida");
        }
    }

    private void validarActividadValida(String nombreActividad) {
        if (!ACTIVIDADES_VALIDAS.contains(nombreActividad)) {
            throw new RuntimeException("La actividad seleccionada no pertenece a EcoHarmony Park");
        }
    }

    private void validarHorario(String horario) {
        if (horario == null || horario.isEmpty()) {
            throw new RuntimeException("El horario seleccionado no puede estar vacío");
        }
        if (!HORARIO_PATTERN.matcher(horario).matches()) {
            throw new RuntimeException("El formato del horario es inválido");
        }
    }

    private void validarHorarioDisponible(Actividad actividad, String horario) {
        if (!actividad.isHorarioDisponible(horario)) {
            throw new RuntimeException("El horario seleccionado no está disponible para esta actividad");
        }
    }

    private void validarParqueAbierto(String horario) {
        int hora = Integer.parseInt(horario.substring(0, 2));
        if (hora < HORA_APERTURA || hora >= HORA_CIERRE) {
            throw new RuntimeException("No se pueden realizar inscripciones en horarios donde el parque está cerrado");
        }
    }

    private void validarCantidadPersonas(int cantidad) {
        if (cantidad < 0) {
            throw new RuntimeException("La cantidad de personas no puede ser negativa");
        }
        if (cantidad < 1) {
            throw new RuntimeException("La cantidad de personas a inscribir debe ser al menos 1");
        }
    }

    private void validarCuposDisponibles(Actividad actividad, String horario, int cantidad) {
        if (actividad.getCuposDisponibles(horario) < cantidad) {
            throw new RuntimeException("No hay suficientes cupos disponibles para este horario");
        }
    }

    private void validarTalle(boolean requiereTalle, String talle) {
        if (requiereTalle) {
            if (talle == null || talle.isEmpty()) {
                throw new RuntimeException("La actividad requiere especificar una talla de vestimenta");
            }
            if (!talle.matches("[A-Za-z]+")) {
                throw new RuntimeException("La talla de vestimenta contiene caracteres inválidos");
            }
            if (!TALLES_VALIDOS.contains(talle.toUpperCase())) {
                throw new RuntimeException("La talla de vestimenta ingresada no es válida");
            }
        }
    }

    private void validarTerminos(boolean aceptaTerminos) {
        if (!aceptaTerminos) {
            throw new RuntimeException("Debe aceptar los términos y condiciones para inscribirse");
        }
    }

    private void validarNoDobleInscripcion(String dni, Actividad actividad, String horario) {
        if (actividad.isInscrito(dni, horario)) {
            throw new RuntimeException("El visitante ya se encuentra inscrito en esta actividad para el horario seleccionado");
        }
    }
}
