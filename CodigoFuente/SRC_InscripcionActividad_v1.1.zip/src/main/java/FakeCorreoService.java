public class FakeCorreoService {
    private static boolean mailEnviado = false;

    public static void enviarMail() {
        mailEnviado = true;
    }

    public boolean seEnvioElMail() {
        return mailEnviado;
    }

    public static void reset() {
        mailEnviado = false;
    }
}
